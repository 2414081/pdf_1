
import pandas as pd
import os
from openpyxl import load_workbook

# ============================================================
# PASS / FAIL CONFIG
# ============================================================

PASS_FAIL_THRESHOLDS = {
    "groundtruth_accuracy_prompt": 0.75,
    "completeness_evaluation_prompt": 0.70,
    "qc_relevency_prompt": 0.75,
    "context_recall_prompt": 0.75,
    "hallucination_cove_prompt": 0.21,          # lower is better
    "hallucination_consistency_prompt": 0.21,   # lower is better
}

# Direction rules: >= for normal metrics, < for hallucination metrics
PASS_FAIL_RULES = {
    "groundtruth_accuracy_prompt": ">=",
    "completeness_evaluation_prompt": ">=",
    "qc_relevency_prompt": ">=",
    "context_recall_prompt": ">=",
    "hallucination_cove_prompt": "<",
    "hallucination_consistency_prompt": "<",
}

def is_pass(metric_key: str, score: float) -> bool:
    """Return True if score passes the rule for metric_key."""
    thresh = PASS_FAIL_THRESHOLDS.get(metric_key)
    rule = PASS_FAIL_RULES.get(metric_key, ">=")

    if thresh is None or score is None:
        return False

    try:
        s = float(score)
    except Exception:
        return False

    if rule == ">=":
        return s >= thresh
    elif rule == "<":
        return s < thresh
    return False

# Mapping: DataFrame column name -> metric key
METRIC_MAP = {
    "Groundtruth Accuracy": "groundtruth_accuracy_prompt",
    "Completeness": "completeness_evaluation_prompt",
    "QC Relevancy": "qc_relevency_prompt",
    "Context Recall": "context_recall_prompt",
    "Hallucination Consistency Score": "hallucination_consistency_prompt",
    "Hallucination CoVe": "hallucination_cove_prompt",
}

ALL_METRIC_COLUMNS = list(METRIC_MAP.keys())

def row_all_metrics_pass(row: pd.Series) -> bool:
    """Return True only if the row passes all metrics."""
    for col, key in METRIC_MAP.items():
        if col not in row.index:
            return False
        if not is_pass(key, row[col]):
            return False
    return True

# ============================================================
# 1. LOAD EXCEL
# ============================================================

path = r"Metric Evaluation Results.xlsx"
xls = pd.ExcelFile(path)
first_sheet = xls.sheet_names[0]
df = pd.read_excel(path, sheet_name=first_sheet)

print("Using sheet:", first_sheet)
print("Rows:", len(df))
print("Columns:", df.columns.tolist())

required_cols = ["question_type", "topic", "sub_topic"]
missing_required = [c for c in required_cols if c not in df.columns]
if missing_required:
    raise KeyError(f"Missing required columns: {missing_required}")

# ============================================================
# 2. DISAGGREGATED ANALYSIS (STRUCTURED) BY question_type
# ============================================================

disagg_qtype_rows = []
for qtype, group in df.groupby("question_type", dropna=False):
    total = len(group)
    pass_count = sum(row_all_metrics_pass(row) for _, row in group.iterrows())
    fail_count = total - pass_count
    disagg_qtype_rows.append([qtype, total, pass_count, fail_count])

disagg_qtype_df = pd.DataFrame(
    disagg_qtype_rows,
    columns=["question_type", "Total Records", "Pass (ALL metrics)", "Fail (ALL metrics)"]
).sort_values(by="Total Records", ascending=False)

# ============================================================
# 3. DISAGGREGATED ANALYSIS (STRUCTURED) BY Topic & Sub topics
# ============================================================

df["topic_sub"] = df["topic"].astype(str) + " - " + df["sub_topic"].astype(str)

disagg_topic_rows = []
for ts, group in df.groupby("topic_sub", dropna=False):
    total = len(group)
    pass_count = sum(row_all_metrics_pass(row) for _, row in group.iterrows())
    fail_count = total - pass_count
    disagg_topic_rows.append([ts, total, pass_count, fail_count])

disagg_topic_df = pd.DataFrame(
    disagg_topic_rows,
    columns=["Topic - Sub topic", "Total Records", "Pass (ALL metrics)", "Fail (ALL metrics)"]
).sort_values(by="Total Records", ascending=False)

# ============================================================
# 4. OUTPUT FILE (NO Aggregated Scores sheet/table)
# ============================================================

output_path = os.path.join("reports", "agg_score_all_metrics.xlsx")
os.makedirs(os.path.dirname(output_path), exist_ok=True)

# Write all required sheets in one go (avoids extra sheet issues)
with pd.ExcelWriter(output_path, engine="openpyxl", mode="w") as writer:

    # --- New requested sheets ---
    disagg_qtype_df.to_excel(
        writer,
        index=False,
        sheet_name="Disagg ALL Metrics (QType)"
    )

    disagg_topic_df.to_excel(
        writer,
        index=False,
        sheet_name="Disagg ALL Metrics (Topic-Sub)"
    )

    # --- Keep rest same ---
    df.to_excel(writer, index=False, sheet_name="Test Data")

    metrics_interpretability = pd.DataFrame({
        "Metrics": ALL_METRIC_COLUMNS,
        "Description": [f"Description for {metric}" for metric in ALL_METRIC_COLUMNS],
        "Score Interpretability": [f"Interpretability for {metric}" for metric in ALL_METRIC_COLUMNS],
        "Approach taken": ["LLM"] * len(ALL_METRIC_COLUMNS),
        "Threshold": [PASS_FAIL_THRESHOLDS[METRIC_MAP[metric]] for metric in ALL_METRIC_COLUMNS],
        "aggregate_score": [round(pd.to_numeric(df[metric], errors='coerce').mean(), 2) for metric in ALL_METRIC_COLUMNS]
    })
    metrics_interpretability.to_excel(writer, index=False, sheet_name="Metrics Interpretability")

    metrics_pass_fail = []
    for metric in ALL_METRIC_COLUMNS:
        total_tcs = len(df)
        failed = sum(not is_pass(METRIC_MAP[metric], row[metric]) for _, row in df.iterrows())
        passed = total_tcs - failed
        skipped = 0
        metrics_pass_fail.append([metric, total_tcs, failed, passed, skipped])

    metrics_pass_fail_df = pd.DataFrame(
        metrics_pass_fail,
        columns=["Metrics", "Total TCs", "Failed", "Passed", "Skipped"]
    )
    metrics_pass_fail_df.to_excel(writer, index=False, sheet_name="Metrics_wise Pass-Fail")

    overall_failed = metrics_pass_fail_df["Failed"].sum()
    overall_passed = metrics_pass_fail_df["Passed"].sum()
    overall_skipped = metrics_pass_fail_df["Skipped"].sum()

    overall_summary = pd.DataFrame({
        "Test Cases Executed": [len(df)],
        "Overall Failed": [overall_failed],
        "Overall Passed": [overall_passed],
        "Overall Skipped": [overall_skipped]
    })
    overall_summary.to_excel(writer, index=False, sheet_name="Overall Summary")

# ============================================================
# 5. Remove default "Sheet" if it exists (Sheet1 cleanup)
# ============================================================

wb = load_workbook(output_path)
if "Sheet" in wb.sheetnames and len(wb.sheetnames) > 1:
    wb.remove(wb["Sheet"])
    wb.save(output_path)

print("✅ Saved:", output_path)
