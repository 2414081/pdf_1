```mermaid
graph LR
    subgraph "<b>User Interaction & Configuration"
        A("<b>Streamlit UI</b><br>Central hub for user interaction")
        B("<b>Configuration</b><br>- Models & Data Sources<br>- Processing Parameters<br>- Testset & Agent Settings")
        A -- Provides --> B
    end

    subgraph "<b>Test Data Generation Pipeline"
        C("<b>1. Document Processing</b><br>- Ingest & Chunk Documents")
        D("<b>2. Vectorization</b><br>- Generate Embeddings<br>- Create Vector Store")
        E("<b>3. Test Set Generation</b><br>- Create QA pairs via Giskard")
        C --> D
        C --> E
    end

    subgraph "<b>Core AI & Evaluation"
        F("<b>4. Agentic RAG Pipeline </b><br>- Retrieve, Generate & Grade<br>- (LangGraph)")
        F1("<b>4.1 Fast API Chatbot Endpoint</b>")
        F2("<b>4.2 Test Set Augmentation</b><br>- Enhance Test Set<br>- Add Edge Cases & Variations")
        G("<b>5. Evaluation Pipeline</b><br>- Run Test Set<br>- Calculate Metrics (DeepEval)")
        F --> F1
        F1 --> F2
        F2 --> G
    end
    
    subgraph "<b>Outputs & Results"
        H("<b>Dashboards & Visualizations</b><br>- View KB, Embeddings, Test Sets<br>- See Evaluation Results")
    end

    %% Define Major Workflow Connections
    B --> C
    D -- "Provides Retriever" --> F
    E -- "Provides Test Set" --> F2
    F -- "Is Evaluated By" --> G
    
    %% Define UI Connections
    A -- Triggers --> C
    A -- Triggers --> F
    A -- Triggers --> G
    
    D -- "Displayed In" --> H
    E -- "Displayed In" --> H
    F -- "Results Displayed In" --> H
    G -- "Results Displayed In" --> H
    H -- "Rendered In" --> A

    %% Style Nodes for a Cognizant-themed blue look
    style A fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style B fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style C fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style D fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style E fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style F fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style F1 fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style F2 fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style G fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    style H fill:#F0F8FF,stroke:#0055D9,stroke-width:2px,color:#002266
    linkStyle default stroke:#0055D9,stroke-width:2px


