# RAG Studio: GEN-AI Automation Testing Framework

**RAG Studio** is an interactive Streamlit application for generating, augmenting, and evaluating QA test sets from enterprise documents using Retrieval-Augmented Generation (RAG) techniques. It integrates advanced LLMs (Azure OpenAI, Gemini), vector search, document chunking, agentic workflows, and custom evaluation metrics for robust test automation.

![RAG Studio Demo](media/demo.gif)

---

## Features

- **Document Ingestion**: Upload or link PDF, DOCX, PPTX, or TXT files.
- **Customizable Chunking**: Adjust chunk size and overlap for document segmentation.
- **Embedding Generation**: Use Azure OpenAI or Gemini for document embeddings.
- **Vector Store Creation**: Builds a FAISS index for semantic retrieval.
- **Testset Generation**: Automatically creates diverse QA pairs using multiple question generators.
- **Augmentation Module**: Produces paraphrased and varied question versions via LLM-powered techniques.
- **Review & Modification**: Accept, reject, or edit questions; add custom ones.
- **Agentic RAG Query Testing**: Interactive pipeline with retrieval, grading, and anti-hallucination checks.
- **API Response Collection**: Sends accepted questions to a FastAPI endpoint and stores bot responses.
- **Advanced Metrics & Evaluation**: DeepEval and GEval metrics for single- and multi-turn QA, with downloadable visualizations.

---

## End-to-End Workflow

### 1. **Setup & Configuration**

- **Environment Variables**:  
  Populate `.env` with keys for Azure OpenAI and/or Gemini:
  ```
  AZURE_OPENAI_ENDPOINT=...
  AZURE_OPENAI_API_KEY=...
  AZURE_OPENAI_DEPLOYMENT_NAME=... (i.e. gpt-4o, gemini-1.5-pro)
  AZURE_OPENAI_API_VERSION=...
  AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT_NAME=... (i.e. text-embedding-ada-002)
  GEMINI_API_KEY=...
  ```
- **Run the App**:  
  ```bash
  streamlit run app.py
  ```

### 2. **Main Processing Tab**

- **Model & Testset Configuration**:  
  Select model provider (Azure OpenAI/Gemini), number of test questions, and chunking parameters.
- **Document Input**:  
  Upload files or provide URLs. Supported formats: PDF, DOCX, PPTX, TXT.
- **Chunking**:  
  Documents are split into chunks with customizable size/overlap.
- **Knowledge Base Creation**:  
  Extracted chunks and metadata saved to `data/knowledge_base.csv`.
- **Embeddings & FAISS Index**:  
  Each chunk is embedded; FAISS index is created for fast vector search.
- **Visualization**:  
  t-SNE and UMAP are computed for embedding visualization.
- **Agentic RAG Pipeline**:  
  LangGraph workflow initialized for retrieval, answer generation, and grading.
- **Testset Generation**:  
  QA pairs automatically generated using multiple question types and saved as JSONL/Excel.

### 3. **Knowledge Base Tab**

- **Browse Knowledge Base**:  
  View and download the chunked document data with metadata.

### 4. **Embeddings Tab**

- **Inspect Embeddings**:  
  Explore document embeddings, t-SNE/UMAP visualizations, and histograms.
- **Interactive Plots**:  
  2D/3D scatter plots for document similarity.

### 5. **Agentic RAG Query Testing Tab**

- **Manual QA Testing**:  
  Submit a question to the agentic pipeline.
- **Pipeline Steps**:  
  - Retrieve relevant chunks.
  - Grade retrieval relevance.
  - Generate answer.
  - Grade answer for hallucination and correctness.
  - Optionally regenerate until answer passes all criteria.

### 6. **Testset Tab**

- **Augmentation Module**:  
  Select augmentation techniques (paraphrasing, synonyms, multilingual, etc.) and generate variants.
- **Review & Modify**:  
  Accept/reject questions, add custom ones, and download final testset.

### 7. **API Response Collection Tab**

- **Send to FastAPI Endpoint**:  
  Only accepted questions are sent to the McDonalds Tririga Chatbot FastAPI Endpoint
- **Response Storage**:  
  Responses from Tririga Chatbot are saved as JSON for further evaluation.

### 8. **Evaluation Tab**

- **Metrics Selection**:  
  Choose between DeepEval and GEval (single/multi-turn).
- **Custom Metrics**:  
  Define new metrics with thresholds and evaluation steps for GEval
- **Run Evaluation**:  
  Assess system responses with chosen metrics; results saved as Excel/JSON.
- **Visualization**:  
  Interactive charts for score distributions, pass/fail rates, and summary statistics.

---

## Architecture

- **Streamlit UI**:  
  Interactive, multi-tab experience with custom CSS.
- **Document Loading**:  
  Uses LangChain loaders for various file types.
- **Vector Store**:  
  FAISS for similarity search.
- **LLM Integration**:  
  Azure OpenAI and Gemini for embeddings, augmentation, and evaluation.
- **LangGraph Agentic Workflow**:  
  Modular agent with retrieval, grading, and answer generation nodes.
- **Evaluation**:  
  DeepEval and GEval for robust QA metric assessment.
- **API Integration**:  
  FastAPI endpoint for live bot responses.

---

## File Structure

```
app.py                # Main Streamlit app with all workflow tabs
logo/                 # Logo and icon images
data/                 # Generated knowledge base, embeddings, testsets, results
.env                  # API keys and endpoints
```

---

## Requirements

- Python 3.9+
- `altair`, `giskard`, `numpy`, `pandas`, `plotly`, `requests`, `streamlit`, `umap-learn`, `deepeval`, `python-dotenv`, `langchain`, `langchain-community`, `langchain-core`, `langchain-google-genai`, `langchain-openai`, `faiss-cpu`, `openpyxl`, `scikit-learn`, `docx2txt`, `pypdf`, etc.
- See `requirements.txt` (if present) or manually install dependencies.

```bash
pip install -r requirements.txt
```

**RAG Studio**: Accelerate QA automation with GenAI-powered document understanding and robust evaluation.
