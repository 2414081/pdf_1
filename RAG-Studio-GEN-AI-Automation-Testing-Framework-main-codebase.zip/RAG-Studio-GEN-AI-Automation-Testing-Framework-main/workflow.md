# Project Workflow

```mermaid
graph TD
    subgraph UI[Streamlit User Interface]
        A1[Configuration Inputs] -->|Model Provider| B[Model Config: Azure OpenAI/Gemini]
        A1 -->|Files/URLs| C[Document Ingestion]
        A1 -->|Chunk Size/Overlap| D[Chunking Parameters]
        A1 -->|Question Types| E[Testset Customization]
        A1 -->|Prompt/Description| F[RAG/Agentic Config]
        A2[Tabs: Main, KB, Embeddings, Agentic RAG, Testset, API, Evaluation]
    end

    subgraph Document Processing
        C -->|PDF, DOCX, PPTX, TXT| I[Document Loaders: PyPDF, Docx2txt, etc.]
        D --> J[Text Splitter: RecursiveCharacterTextSplitter]
        I -->|Text Extraction| J
        J -->|Chunks with Metadata| K[Knowledge Base]
    end

    subgraph Knowledge Base
        K -->|CSV Generation| L[knowledge_base.csv]
        K -->|Giskard KnowledgeBase| M[Testset Generation GISKARD]
    end

    subgraph Embedding & Vector Store
        J -->|Chunks| G[Embedding Model: text-embedding-ada-002/text-embedding-004]
        G -->|Embeddings| N[FAISS Vector Store]
        N -->|Save| O[faiss_index]
        G -->|Embeddings| P[Embedding DataFrame]
        P -->|t-SNE/UMAP| Q[Reduced Embeddings]
    end

    subgraph Visualizations
        P -->|Histogram| R[Altair: Embedding Histogram]
        Q -->|2D/3D Scatter| S[Plotly: t-SNE/UMAP Scatter]
    end

    subgraph Agentic RAG Pipeline
        N -->|Retriever| T1[LangGraph: retrieve_documents]
        T1 --> T2[LangGraph: retrieval_grader]
        T2 --> T3[LangGraph: generate_answer]
        T3 --> T4[LangGraph: hallucination_grader]
        T4 --> T5[LangGraph: answer_grader]
        T5 -->|Conditional: regenerate if needed| T3
        T5 -->|Final Output| U1[Agentic RAG Query Testing Tab]
        U1 -->|Display Answer, Scores, Reasoning| V1[UI Output]
    end

    subgraph Testset Generation
        M -->|Question Generators: Simple, Complex, etc.| W[Testset]
        E --> W
        W -->|Save| X[testset.jsonl]
        W -->|Convert| Y[output.xlsx]
        W -->|Display| Z[Testset Tab]
    end

    subgraph Evaluation
        W -->|Test Cases| AA[Evaluation: DeepEval/GEval]
        AA -->|Single-Turn| AB[Metrics: Precision, Relevancy, etc.]
        AA -->|Multi-Turn| AC[Conversational Metrics]
        AA -->|Custom Metrics| AG[GEval Custom Metrics]
        AB -->|Results| AD[single_deepeval/geval_output.xlsx]
        AC -->|Results| AE[multi_deepeval/geval_output.xlsx]
        AB -->|Visualizations| AF[Plotly: Bar, Box, Pie Charts]
        AC -->|Visualizations| AF
    end

    subgraph Outputs
        L -->|Download| AI[CSV Download]
        X -->|Download| AI[JSONL Download]
        Y -->|Download| AI[Excel Download]
        AD -->|Download| AI
        AE -->|Download| AI
        AF -->|Download| AH[Chart JSON]
    end

    A2 -->|Display| K
    A2 -->|Display| P
    A2 -->|Display| Q
    A2 -->|Display| R
    A2 -->|Display| S
    A2 -->|Display| V1
    A2 -->|Display| Z
    A2 -->|Display| AF
```
